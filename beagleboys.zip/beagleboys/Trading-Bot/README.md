# Trading-Bot
un projet de robot trader pour une MSPR EPSI
