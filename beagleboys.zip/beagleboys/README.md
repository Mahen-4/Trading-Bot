# Beagleboys

Un projet de robot trader pour une MSPR EPSI

## Notation

Robot sur 8 points
IHM sur 5 points
Participation sur 8 points
Documentation & clarté du code sur 2 points

Oui ça fait 23, je verrai comment je remet sur 20 en fonction des résultats.

## Copies et autre

Si vous vous êtes largement inspiré d'un autre projet, merci d'en indiquer la source (que ce soit un autre groupe ou un projet sur le web). Je n'ai pas envie de relire deux fois le même code.
## Date limite de rendu

Le code doit être figé le 14 mars avant minuit.
Le 15 mars, je fais un git pull de tous les robots. Je lance mon script.
Les trois premiers ont un bonus de 3,2,1 points (note maximale 20).
