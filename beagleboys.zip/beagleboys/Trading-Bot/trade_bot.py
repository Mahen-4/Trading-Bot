#ATHTHANAYAKA MUDALIGE Mahen   
#BOURAS Mehdi BOUBAKEUR
#IBRAHIMI Adam



import json
import threading
import pandas as pd
import mplfinance as mpl


class TradeBot:
    def __init__(self, client):
        self.start_money = 100000
        self.client = client
        self.money = self.start_money
        self.actions = {}
        self.prices = {}
        self.keys = []
        self.volume = []
        self.data = []

    def process_candle(self, message):
        """
        Called for every messsage in stock data
        """
        parsed = json.loads(message)
        for k, v in parsed.items(): # lecture du fichier txt
            if "c" in v:
                self.prices[k] = v["c"]
            self.keys.append(k)
            self.volume.append(v["v"])

            if "AMZN" in parsed:  # L'action qu'on va montrer dans le graphique candlestick
                self.data.append(v)

            self.choix(parsed, "AMZN", v)
            self.choix(parsed, "ATVI", v)
            self.choix(parsed, "TSLA", v)
            self.choix(parsed, "DIS", v)
            self.choix(parsed, "AAPL", v)
            self.choix(parsed, "BINANCE:BTCUSDT", v)
            

    def strat1(self,parsed,action,v): #stratégie 
        if action in parsed: 
            if parsed[action]['o'] == parsed[action]['l']:
                if self.client.money > parsed[action]['c']:
                    self.client.buy(action,1)
            elif parsed[action]['o'] == parsed[action]['h']:
                if self.client.actions[action] > 0:
                    self.client.sell(action,1)       

    def strat2(self, parsed, action, v): # stratégie 2
        if action in parsed:
            if 1000 < parsed[action]["v"] < 10000:
                if self.client.money > parsed[action]["c"]:
                    self.client.buy(action, 1)
            elif 0 < parsed[action]["v"] < 1000:
                if self.client.actions[action] > 0:
                    self.client.sell(action, 1)
            else:
                self.strat1(parsed, action, v)

    def choix(self, parsed, action, v): # fonction qui va décider si on achète l'action
        if action in parsed:
            if 1000 < parsed[action]["c"] < 100000:
                self.strat2(parsed, action, v)
            else: 
                self.strat1(parsed, action, v)


    def plot(self): #fonction qui va affichage le graphique candlestick
        df = pd.DataFrame(self.data)
        df.index = pd.to_datetime(df["t"], unit="s")  # met les date en index
        df = df.rename(columns={"o": "Open", "h": "High", "l": "Low", "c": "Close", "v": "Volume"})  # rename column
        df = df.loc["2022-02-01 23:00":"2022-02-02 17:00"]  # interval de date afficher
        mpl.plot(df, title="AMZN ACTIONS CANDLESTICK GRAPH", type="candle", style="charles", volume=True, mav=5)#mav = moving average (moyenne mobile)
